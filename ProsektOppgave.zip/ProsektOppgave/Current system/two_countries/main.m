clear all; close all;

Td = 0.2;          % Time constant debtor countries
Tc = 0.3;           % Time constant creditor countries
Tcf = 0;           % Time constant creditor finantial behaviour
lambda_k = 0.005;   % Non crisis loss rate on debt
r_k = 0.1;         % repayment rate 
i_k = 0.04;         % interst rate
sigma = 0.17;%.1;        % surpluss used on financial activity (not for imports)
sigma_KF =0.75;%.75;     % relending factor from interest and repayment
exchange_rate = 1;
initialM_d = 5.07458157406819;
initialM_c = 14.9254184259318;
rho = 0.3;          %Outside spending coeficcient 
rhoG = 0.2;




sim('two_countries.slx');
values = ans.simout;
t = ans.tout;
BNP_D = values(:,1);
BNP_C = values(:,2);
Money_in_d = values(:,3);
Money_in_c = values(:,4);
trade_balance = values(:,5);
pulse = values(:,6);
tot_trade_balance = values(:,7);

%% Plot 

figure(1)
plot(t,BNP_D);
hold on;
plot(t,BNP_C);
title('BNP');
legend('BNP_{Greece}','BNP_{Germany}');

figure(2)
plot(t,Money_in_d);
hold on;
plot(t,Money_in_c);
title('Trade');
legend('Money in debtor','Money in creditor');

figure(3)
%yyaxis left;
plot(t,trade_balance);
title('Trade balance','fontsize',18, 'Interpreter','latex');
% yyaxis right;
% plot(t,pulse);
xlabel('time [years]','fontsize',18, 'Interpreter','latex');
ylabel('trade balance','fontsize',18, 'Interpreter','latex');
%set(gca, 'YTick', []);%,'XTick',[]


figure(3)
plot(t,tot_trade_balance);
title('Total trade balance','fontsize',18, 'Interpreter','latex');
xlabel('Time [years]','fontsize',16, 'Interpreter','latex');
ylabel('Money [Euros]','fontsize',16, 'Interpreter','latex');
