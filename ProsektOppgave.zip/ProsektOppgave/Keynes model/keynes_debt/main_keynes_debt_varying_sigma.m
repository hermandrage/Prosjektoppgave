clear all; close all;
K=0.1;
Kp=10;
Ki=1;
Kd=10;
T=10;
i=0.03; 



Td = 0.2;          % Time constant debtor countries
Tc = 0.3;           % Time constant creditor countries
Tcf = 0;           % Time constant creditor finantial behaviour
lambda_k = 0.005;   % Non crisis loss rate on debt
r_k = 0.1;         % repayment rate 
i_k = 0.04;         % interst rate
sigma = 0.17;%.1;        % surpluss used on financial activity (not for imports)
sigma_KF =0.75;     % relending factor from interest and repayment
exchange_rate = 1;
initialM_d = 4;%6;
initialM_c = 16;%14;
rho = 0.3;          %Outside spending coeficcient 
rhoG = 0.2;


sim('keynes_debt_sigma.slx');
values = ans.simout;
t = ans.tout;
e_rate = values(:,1);
Td = values(:,2);
Tc = values(:,3);
BNP_d = values(:,4);
BNP_c = values(:,5);
import_d = values(:,6);
import_c = values(:,7);
Balance_D = values(:,8);
debt = values(:,9);
%% Plot 

figure(1)
plot(t,e_rate);
title('exchange rate');

figure(2)
plot(t,Td);
hold on;
plot(t,Tc);
title('Time lags');
legend('T_d','T_c');

figure(3)
plot(t,BNP_d);
hold on;
plot(t,BNP_c);
title('BNP');
legend('BNP_{Greece}','BNP_{Germany}');

figure(4)
%yyaxis left
plot(t,import_d);
hold on;
plot(t,import_c);
title('Trade', 'fontsize',18, 'Interpreter','latex');
% yyaxis right
% plot(t,e_rate);
legend('import_d','import_c', 'Interpreter','latex');%,'exchange rate');
xlabel('time [years]','fontsize',14, 'Interpreter','latex');
ylabel('moneyflow [Euros/years]', 'fontsize',14, 'Interpreter','latex');

figure(5)
plot(t,Balance_D);
title('Total trade balance', 'fontsize',18, 'Interpreter','latex');
xlabel('time [years]','fontsize',14, 'Interpreter','latex');
ylabel('money [Euros]', 'fontsize',14, 'Interpreter','latex');

figure(6)
plot(t,debt);
title('Debt','fontsize',18, 'Interpreter','latex');
xlabel('time [years]','fontsize',14, 'Interpreter','latex');
ylabel('money [Euros]', 'fontsize',14, 'Interpreter','latex');


